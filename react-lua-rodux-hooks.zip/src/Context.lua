local React = require(script.Parent.Parent.React)

local Context = React.createContext()

return Context
